﻿// create the module and name it myStore
var myStore = angular.module('myStore', ['ngRoute', 'ngCookies']);

// configure our routes
myStore.config(['$locationProvider', function ($locationProvider) {
    $locationProvider.hashPrefix('');
}]);
myStore.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        // route for the home page
        .when('/', {
            templateUrl: 'components/home/Home.html',
            controller: 'mainController'
        })

        // route for the login page
        .when('/login', {
            templateUrl: 'components/login/Login.html',
            controller: 'loginController'
        })

        // route for the registration page
        .when('/register', {
            templateUrl: 'components/Registration/Registration.html',
            controller: 'registerController'
        })

        // route for the albums intarface  page
        .when('/albumsInterface', {
            templateUrl: 'components/albumsInterface/albumsInterface.html',
            controller: 'albumsInterfaceController'
        })

        // route for the cart page
        .when('/cart', {
            templateUrl: 'components/cart/cart.html',
            controller: 'cartController'
        })

        // route for the about page
        .when('/about', {
            templateUrl: 'components/about/about.html',
            //controller: 'aboutController'
        })
        .otherwise({redirect: '/',
        });
}]);
