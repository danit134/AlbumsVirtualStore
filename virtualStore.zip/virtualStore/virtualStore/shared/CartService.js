﻿myStore.factory('CartService', ['$http', function ($http) {
    let service = {}; //dictionery
    service.startPurchase = false;
    service.orderId = '';
    service.historyOrders = ''; //all the orders that user make before
    service.currentOrderDetails = '';
    service.currentAlbumDetails = '';
    service.showAlbumDetails = false;
    service.logOutPressForOrders = false;
    service.logOutPressForCookie = false;
    service.removePreviusOrders = false;


    service.refreshOrdersDetails = function () {
        service.getOrderDetail().then(function (success) {
            service.updateLocalStorage();
        }, function (error) {
            self.errorMessage = error.data;
            console.log('get orders has failed');
        })
    };

    service.updateLocalStorage = function () {
        localStorage.removeItem(service.orderId);
        localStorage.setItem(service.orderId, JSON.stringify(service.currentOrderDetails));
    };

    service.getOrderDetail = function () {
        return $http.get('http://localhost:3100/getOrderDetail/' + service.orderId).then(function (response) {
            service.currentOrderDetails = response.data;           
            return Promise.resolve(response);
        })
            .catch(function (e) {
                return Promise.reject(e);
            }); 
    };

    service.getOrderId = function (orderDetails) {
        return $http.post('http://localhost:3100/getOrderID', orderDetails).then(function (response) {
            var result = response.data;
            service.orderId = result[''];
            service.updateLocalStorage();
            return Promise.resolve(response);
        })
            .catch(function (e) {
                return Promise.reject(e);
            });      
    };

    service.startPurchaseOnServer = function (user) {
        return $http.post('http://localhost:3100/startNewPurchase', user).then(function (response) {
            var result = response.data;
            service.startPurchase = true;
            return Promise.resolve(response);
        })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    service.addAlbumToCart = function (AlbumDetails) {
        return $http.post('http://localhost:3100/addItemToPurchase', AlbumDetails)
            .then(function (response) {
                var result = response.data;                
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    service.removeOrder = function () {
        return $http.post('http://localhost:3100/DeleteOrder', { OrderID: service.orderId })
            .then(function (response) {
                var result = response.data;
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    service.albumDetails = function (albumID) {
        service.showAlbumDetails = false;
        return $http.get('http://localhost:3100/getAlbumInfo/' + albumID)
            .then(function (response) {
                var result = response.data;
                service.currentAlbumDetails = result[0];
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    //instead of showing details of category number.. replace the numberin the genere name
    service.getFilterCategoryName = function () { 
        return $http.get('http://localhost:3100/getFilterCategory/' + service.currentAlbumDetails.FilterCategoryID)
            .then(function (response) {
                var result = response.data;
                service.currentAlbumDetails.FilterCategoryID = result[0].CategoryName;
                service.showAlbumDetails = true;
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    return service;
}]);

    //the index.html and more pages need access to the fields in this service that belong to login service
myStore.controller('cartServiceController', ['CartService', '$http', '$location', function (CartService, $http, $location) {
    let self = this;
    self.cartService = CartService;

    self.albumDetails = function (albumID) {
        CartService.albumDetails(albumID).then(function (success) {
            CartService.getFilterCategoryName().then(function (success) {
            }, function (error) {
                self.errorMessage = error.data;
                console.log('get filter category name has failed');
            })
        }, function (error) {
            self.errorMessage = error.data;
            console.log('get album details has failed');
        })
    };

    self.removeOrder = function () {
        CartService.removeOrder().then(function (success) {
            self.removeItemsFromCart();
            self.initCart();
        }, function (error) {
            console.log('Error while delete order');
        })
    };

    self.removeItemsFromCart = function () {
        angular.forEach(CartService.currentOrderDetails, function (value, key) {
            self.needToDelete = { OrderID: CartService.orderId, AlbumID: value.AlbumID, Amount: value.Amount };
            $http.post('http://localhost:3100/DeleteItemToPurchase', self.needToDelete).then(function (response) {
            }, function (errResponse) {
                console.log('Error while delete album in current order');
            });
        });
    };

    self.initCart = function () {
        CartService.startPurchase = false;
        CartService.orderId = '';
        CartService.currentOrderDetails = '';
    };

    //when the user dont logout the remove items dont happen. (because he refresh the page and dont press logout) so with local storage we remember the last shopping and delete it when the home page loaded again.
    self.removePreviusOrders = function () {
        if ((CartService.removePreviusOrders == false) || (CartService.logOutPressForOrders )){
            for (var key in localStorage) {
                CartService.orderId = key;
                CartService.currentOrderDetails = JSON.parse(localStorage.getItem(key));
                self.removeOrder();
                localStorage.removeItem(key);
            }
            CartService.removePreviusOrders = true;
            CartService.logOutPressForOrders = false;

        }
    };

}]);
