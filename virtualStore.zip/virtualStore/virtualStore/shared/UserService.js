﻿myStore.factory('UserService', ['$http', 'CartService', function ($http, CartService) {
    let service = {}; //dictionery
    service.isLoggedIn = false;//. somthing is key. = somthing is value
    service.userName = '';
    service.lastLogInDate = '';
    

    service.login = function (user) {
        return $http.post('http://localhost:3100/Login', user)
            .then(function (response) {
                var result = response.data;
                if (result == 'true') {
                    service.isLoggedIn = true;
                    service.userName = user.Username;      
                }
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    service.getLastLogInDate = function (username) {
        return $http.get('http://localhost:3100/getSpecificClient/' + username)
            .then(function (response) {
                var result = response.data;
                service.lastLogInDate = (result[0].lastTimeLoginIn);
                if (service.lastLogInDate == null)
                    response = '';
                else
                {
                    service.lastLogInDate = service.lastLogInDate.substring(0, 10);
                }

                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };


    service.register = function (user) {
        return $http.post('http://localhost:3100/registerClient', user)
            .then(function (response) {
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };

    return service;
}]);

//the index.html and more pages need access to the isLoggedIn and userName fields that belong to login service
myStore.controller('loginServiceController', ['UserService', function (UserService) {
    let vm = this;
    vm.userService = UserService;

}]);