﻿myStore.controller('cartController', ['UserService', 'CartService', '$window', '$scope', '$route', '$http', '$location', function (UserService, CartService, $window, $scope, $route, $http, $location) {
    var self = this;
    self.orderDetailsTabActive = false;
    //self.currentOrderDetails = '';
    self.totalAmountCurrentCart = 0;
    self.historyOrders = CartService.historyOrders;
    self.orderIDTabThree = '';
    self.specipicHistoryOrder = '';


    //if the user refresh the page it goes back to the home page
    if (window.performance) {
        //window.performance work's fine on this browser
    }
    if (performance.navigation.type == 1) { //The page reloaded (refresh)
        $location.path('/');
    } else {
        //The page is not reloaded
    }


    $scope.tabs = [
        {
            title: 'Order details',
            url: 'one.tpl.html'
        },
        {
            title: 'Previous orders',
            url: 'two.tpl.html'
        },
        {
            title: 'History order details',
            url: 'three.tpl.html'
        }];

    $scope.currentTab = 'one.tpl.html';

    $scope.onClickTab = function (tab) {
        $scope.currentTab = tab.url;
    }

    $scope.isActiveTab = function (tabUrl) {
        return tabUrl == $scope.currentTab;
    }

    self.getTotalPrice = function () {
        $http.get('http://localhost:3100/getTotalPrice/' + CartService.orderId).then(function (response) {
            var result = response.data[0].grand_total;
            if (result == null) {
                self.totalAmountCurrentCart = 0;
            }
            else {
                self.totalAmountCurrentCart = result;
            }
        }, function (errResponse) {
            console.log('Error while fetching albums in current order');
        });
    };

    if (CartService.startPurchase == true) {
        self.getTotalPrice();
    }

    self.getHistoryOrderDeatails = function (orderId) { //all the albums that the user phorcase in history session
        $http.get('http://localhost:3100/getOrderDetail/' + orderId).then(function (response) {
            self.specipicHistoryOrder = response.data; 
            self.orderIDTabThree = orderId; // the order id the user want to see its details (order that was in the past)
            self.orderDetailsTabActive = true;
            $scope.currentTab = 'three.tpl.html';
        }, function (errResponse) {
            console.log('Error while fetching albums in current order');
        });
    };

    self.removeFromCart = function (albumId, amount) {
        self.needToDelete = { OrderID: CartService.orderId, AlbumID: albumId, Amount: amount};
        $http.post('http://localhost:3100/DeleteItemToPurchase', self.needToDelete).then(function (response) {
            CartService.refreshOrdersDetails();
            self.getTotalPrice();           
        }, function (errResponse) {
            console.log('Error while delete album in current order');
        });
    };

}]);