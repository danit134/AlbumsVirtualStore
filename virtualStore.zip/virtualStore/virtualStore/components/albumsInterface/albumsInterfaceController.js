﻿myStore.controller('albumsInterfaceController', ['UserService', 'CartService', '$window', '$scope', '$http', '$location', function (UserService, CartService, $window, $scope, $http, $location) {
    var self = this;
    self.filterCategory = '';
    self.sortCategory = '';
    self.allAlbums = '';


    //if the user refresh the page it goes back to the home page
    if (window.performance) {
        //window.performance work's fine on this browser
    }
    if (performance.navigation.type == 1) { //The page reloaded (refresh)
        $location.path('/');
    } else {
        //The page is not reloaded
    }


    $scope.query = {}
    $scope.queryBy = 'AlbumName'

    $scope.tabs = [
    {
        title: 'Search albums',
        url: 'search.tpl.html'
    },
    {
        title: 'Albums by genre',
        url: 'one.tpl.html'
    },
    {
        title: 'Sort albums',
        url: 'two.tpl.html'
    },
    {
        title: 'Recommended albums for you',
        url: 'three.tpl.html'
    }];

    $scope.currentTab = 'search.tpl.html';

    $scope.onClickTab = function (tab) {
        $scope.currentTab = tab.url;
    }

    $scope.isActiveTab = function (tabUrl) {
        return tabUrl == $scope.currentTab;
    }


   /****************************************************************************************************/

    var count = new Array();//contain all the current quantity the user set on the items on home page

    $scope.init = function (index) {
        count[index] = 0;
    };

    $scope.plus = function (index) {
        count[index]++;
        var countEl = document.getElementById(index);
        countEl.value = count[index];
    };

    $scope.minus = function (index) {
        if (count[index] > 0) {
            count[index]--;
            var countEl = document.getElementById(index);
            countEl.value = count[index];
        }
    };

    /****************************************************************************************************/

    if (UserService.isLoggedIn == true)
    {
        $http.get('http://localhost:3100/getFilterCategories').then(function (response) {
            var returnData = response.data;
            self.generCategories = returnData;
        }, function (errResponse) {
            console.log('Error while fetching categories');
        });

        $http.get('http://localhost:3100/getSortCategories').then(function (response) {
            var returnData = response.data;
            self.sortCategories = returnData;
        }, function (errResponse) {
            console.log('Error while fetching categories');
            });


        $http.get('http://localhost:3100/getRecommendedPerClient/' + UserService.userName).then(function (response) {
            var returnData = response.data;
            self.recAlbums = returnData;
        }, function (errResponse) {
            console.log('Error while fetching categories');
            });

        $http.get('http://localhost:3100/getAlbums').then(function (response) {
            self.allAlbums = response.data;
        }, function (errResponse) {
            console.log('Error while fetching products');
        });
    }

    self.showAlbumsInGenerCategory = function () {
        if (self.filterCategory != '') {
            $http.get('http://localhost:3100/filterByCategory/' + self.filterCategory.FilterCategoryID).then(function (response) {
                var returnData = response.data;
                self.albumsInGenerCategory = returnData;
            }, function (errResponse) {
                console.log('Error while fetching categories');  
            });
        }
        self.albumsInGenerCategory = '';
    };

    self.showAlbumsInSortCategory = function () {
        if (self.sortCategory != '') {
            $http.get('http://localhost:3100/sortByCategory/' + self.sortCategory.SortCategoryID).then(function (response) {
                var returnData = response.data;
                self.albumsInSortCategory = returnData;
            }, function (errResponse) {
                console.log('Error while fetching categories');
            });
        }
        self.albumsInSortCategory = '';
    };


    self.addToCart = function (albumName, albumId, index) {
        var countEl = document.getElementById(index);
        var quantity = countEl.value;
        if (quantity > 0) {
            self.albumDetails = { OrderID: CartService.orderId, AlbumID: albumId, Amount: quantity };
            CartService.addAlbumToCart(self.albumDetails).then(function (success) {
                if (success.data == 'add item succeed') {
                    $window.alert(albumName + ", quantity:" + quantity + " added succecfuly to the cart")
                }
                else if (success.data == 'Amount is bigger than StokAmount') {
                    $window.alert("The quantity you insert is bigger than our available stoke")
                }
                else {
                    $window.alert('add album to cart has failed');
                }
                CartService.refreshOrdersDetails();
            }, function (error) {
                self.errorMessage = error.data;
                console.log('add album to cart has failed');
            })

        }
    };

}]);


