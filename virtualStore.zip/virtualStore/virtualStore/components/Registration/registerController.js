﻿myStore.controller('registerController', ['UserService', '$http', '$location', '$window',
    function (UserService, $http, $location, $window) {
        var self = this;
        self.userDetails = { FirstName:'', LastName: '', City: '', Country: '', Adress: '', Phone: '', Cellular: '', Mail: '', CreditCardNumber: '', isADmin: '0', Username: '', Password: '', favoriteCategory1: '', favoriteCategory2: '' };
        self.countries = AllCountries;
        self.userDetails.Country = AllCountries[4];

        $http.get('http://localhost:3100/getFilterCategories').then(function (response) {
            var returnData = response.data;
            self.categories = returnData;
        }, function (errResponse) {
            console.log('Error while fetching categories');
            });

        self.checkUsernameAndRegister = function (valid) {
            if (valid) {

                $http.get('http://localhost:3100/AvailableUsername/' + self.userDetails.Username).then(function (response) {
                    var returnData = response.data;
                    if (returnData == 'true') {
                        self.userDetails.Country = self.userDetails.Country.Name;

                        //favorite category contain json- so we get only the category id for the register api
                        self.userDetails.favoriteCategory1 = self.userDetails.favoriteCategory1.FilterCategoryID;
                        self.userDetails.favoriteCategory2 = self.userDetails.favoriteCategory2.FilterCategoryID;

                        self.register();
                    }
                    else {
                        $window.alert('this username is already taken, choose diffrent one');
                    }
                }, function (errResponse) {
                    console.log('Error while chacking username');
                });
            }
        };

        self.register = function () {         
            UserService.register(self.userDetails).then(function (success) {
                if (success.data == 'true') {
                    $window.alert('register succeed!');
                    $location.path('/login');
                }
                else {
                    $window.alert('register has failed');
                }
            }, function (error) {
                self.errorMessage = error.data;
                console.log('register has failed');
            })
        };
    }]);

var AllCountries = [{ ID: "1", Name: "Australia" }, { ID: "2", Name: "Bolivia" }, { ID: "3", Name: "China" },
    { ID: "4", Name: "Denemark" }, { ID: "5", Name: "Israel" }, { ID: "6", Name: "Latvia" },
    { ID: "7", Name: "Monaco" }, { ID: "8", Name: "August" }, { ID: "9", Name: "Norway" },
    { ID: "10", Name: "Panama" }, { ID: "11", Name: "Switzerland" }, { ID: "12", Name: "USA" }];
