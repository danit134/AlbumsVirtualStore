﻿myStore.controller('loginController', ['$http', 'UserService', 'CartService', '$scope', '$location', '$window', '$cookies',
    function ($http, UserService, CartService, $scope, $location, $window, $cookies) {
        var self = this;
        self.user = { Username: '', Password: '' };
        self.recoverPassDetails = { Username: '', City: '', LastName: '' };
        self.showForgotPassFields = false;

        self.login = function (valid) {
            if (valid) {
                UserService.getLastLogInDate(self.user.Username).then(function (success) {                
                }, function (error) {
                    self.errorMessage = error.data;
                    console.log('fetch user has failed');
                }).then(
                    UserService.login(self.user).then(function (success) {
                    if (success.data == 'true') {
                            self.createCookie(self.user.Username, self.user.Password);
                            self.getOrderHistory();
                            $location.path('/');
                        }
                        else {
                            $window.alert('The username or/and the password incorrect');
                        }
                    }, function (error) {
                        self.errorMessage = error.data;
                        console.log('login has failed');
                    }))
            }
        };

        self.createCookie = function (username, password) {            
            var currCookie = document.cookie;
            var res = currCookie.split("=");
            if (res[0] == "")
                $cookies.put(username, password);           
            else if (res[0] != username) {
                $cookies.remove(res[0]);
                $cookies.put(username, password);
            }
            
        };

        self.getOrderHistory = function () { //we dont want every time the cart page open the history orders asked again
            $http.get('http://localhost:3100/getHistoryOrdersByID/' + UserService.userName).then(function (response) {
                CartService.historyOrders = response.data;
                //CartService.getHistory = true;
            }, function (errResponse) {
                console.log('Error while fetching categories');
            });
        };

        self.getPassword = function (valid) {
            if (valid) {
                $http.post('http://localhost:3100/validitionQuestionForPassword/', self.recoverPassDetails).then(function (response) {
                    var result = response.data;
                    if (result == 'false, you are not the guy!')
                        $window.alert('The details you provided is not correct!');
                    else {                      
                        $window.alert('Yours password is: ' + result[0].Password);
                    }
                    self.showForgotPassFields = false;
                    self.recoverPassDetails = { Username: '', City: '', LastName: '' };
                }, function (errResponse) {
                    console.log('Error while fetching password');
                });
            }
        };

        self.loginWithCookie = function (cookieUser) {
            if (CartService.logOutPressForCookie == false) {
                if ((cookieUser.Username != "") && (UserService.userName == '')) {
                    UserService.getLastLogInDate(cookieUser.Username).then(function (success) {
                    }, function (error) {
                        self.errorMessage = error.data;
                        console.log('fetch user has failed');
                    }).then(
                        UserService.login(cookieUser).then(function (success) {
                            if (success.data == 'true') {
                                self.getOrderHistory();
                                $location.path('/');
                            }
                            else {
                                $window.alert('login has failed');
                            }
                        }, function (error) {
                            self.errorMessage = error.data;
                            console.log('login has failed');
                        }))
                }
            }
        };
    }]);

