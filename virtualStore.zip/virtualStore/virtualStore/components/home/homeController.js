﻿myStore.controller('mainController', ['UserService', 'CartService', '$http', '$window', '$scope', '$cookies', function (UserService, CartService, $http, $window, $scope, $cookies) {
    var self = this;
    self.cookieUser = '';

    var count = new Array();//contain all the current quantity the user set on the items on home page

    $scope.init = function (index) {
        count[index] = 0;
    };

    $scope.plus = function (index) {
        count[index]++;
        var countEl = document.getElementById(index);
        countEl.value = count[index];
    };

    $scope.minus = function (index) {
        if (count[index] > 0) {
            count[index]--;
            var countEl = document.getElementById(index);
            countEl.value = count[index];
        }
    };

    $scope.homeLoad = function () {
        if (CartService.logOutPressForCookie == false)
        {
            var currCookie = document.cookie;
            var res = currCookie.split("=");
            self.cookieUser = { Username: res[0], Password: res[1] };
        //window.alert(self.cookieUser.Username + " " + self.cookieUser.Password);
        //$cookies.remove('a');
        //var currCookie = document.cookie;
        //window.alert(currCookie);
        }

        $http.get('http://localhost:3100/topFive').then(function (response) {
            var returnData = response.data;
            self.bestAlbums = returnData;
        }, function (errResponse) {
            console.log('Error while fetching products');
        });

        $http.get('http://localhost:3100/getNewAlbums').then(function (response) {
            var returnData = response.data;
            self.newAlbums = returnData;
        }, function (errResponse) {
            console.log('Error while fetching products');
        });
    };



    self.startPurchase = function () {
        CartService.startPurchaseOnServer({ Username: UserService.userName }).then(function (success) {
            self.getOrderId();           
        }, function (error) {
            self.errorMessage = error.data;
            console.log('Error while fetching answer for start purchase');
        })
    };


    self.getOrderId = function () {
        var date = new Date(); // date of today
        $scope.FromDate = date.getFullYear() + ('0' + (date.getMonth() + 1)).slice(-2) + ('0' + date.getDate()).slice(-2);//like: 20170626

        CartService.getOrderId({ Username: UserService.userName, OrderDate: $scope.FromDate }).then(function (success) {           
            $window.alert('Cart open for shopping! start adding albums. Your order id will be:' + CartService.orderId);
            CartService.startPurchase = true;
        }, function (error) {
            self.errorMessage = error.data;
            console.log('Error while fetching orderId');
        })
    };

    self.addToCart = function (albumName, albumId, index) {
        var countEl = document.getElementById(index);
        var quantity = countEl.value;
        if (quantity > 0) {
            self.albumDetails = { OrderID: CartService.orderId, AlbumID: albumId, Amount: quantity };
            CartService.addAlbumToCart(self.albumDetails).then(function (success) {
                if (success.data == 'add item succeed') {
                    $window.alert(albumName + ", quantity:" + quantity + " added succecfuly to the cart")
                }
                else if (success.data == 'Amount is bigger than StokAmount') {
                    $window.alert("The quantity you insert is bigger than our available stoke")
                }
                else {
                    $window.alert('add album to cart has failed');
                }
                CartService.refreshOrdersDetails();
            }, function (error) {
                self.errorMessage = error.data;
                console.log('add album to cart has failed');
            })

        }
    };


}]);




