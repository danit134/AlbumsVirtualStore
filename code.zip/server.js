
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
var cors = require('cors');
app.use(cors());
var Connection = require('tedious').Connection;
var DButilsAzure = require('./DButilsAzure');
var squel = require('squel');
var moment = require('moment');
var root = express.Router()

root.use(function (req,res,next) {
    next('route');
});


var server = app.listen(3100, function () {
   var port =  server.address().port
    var host = server.address().address
    app.use('/',root);
    console.log('I am listening on port: ' + port);
});



//--------------------------------------------------------------------------------------------------------------------
root.get('/getAlbums', function (req,res) {
    var query = "Select * from Albums";
    DButilsAzure.Select(query)
        .then(function(result) {
		res.send(result);
		console.log ('GET albums success');
	})
        .catch(function (error) {
            console.log (error.message);
            res.sendStatus(400);
        })
});

// //-------------------------------------------------------------------------------------------------------------------
//write in url localhost:3100/getAlbumInfo/1 for example
root.get('/getAlbumInfo/:id', function (req,res) {
	var albumId = req.params.id;
	var query = 'Select * from Albums Where AlbumID='+albumId;
	DButilsAzure.Select(query)
        .then(function(result) {
		if (result.length > 0) {
			res.status(200).json(result);
			console.log ('GET album success');
		}
		else {
			console.log ('GET album faild, Incorrect ID');
			res.sendStatus(400);
		}
	});
});
//-------------------------------------------------------------------------
root.post('/addAlbum', function(req, res){
	if(!req.body.AlbumName || !req.body.FilterCategoryID || !req.body.Price || !req.body.usernameAdmin || !req.body.StokAmount) {
        res.send("you need to fill album name, price and category, and  admin username");
        return;
    }
    var query = "Select * from Clients where Username='"+req.body.usernameAdmin+"' and isADmin='1'" ;
    DButilsAzure.Select(query)
        .then(function (result) {
            if(result.length>0) {
                var AlbumName = req.body.AlbumName;
                var ArtistName = req.body.ArtistName;
                var FilterCategoryID = req.body.FilterCategoryID;
                var Description = req.body.Description;
                var PicturePath = req.body.PicturePath;
                var ReleaseDate = req.body.ReleaseDate;
                var releaseDay = moment(ReleaseDate);
                var Price = req.body.Price;
                var StokAmount = req.body.StokAmount;
                var addToDay;
                if (!req.body.addToSystemDate) {
                    addToDay = moment();
                }
                else {
                    var addToSystemDate = req.body.addToSystemDate;
                    addToDay = moment(addToSystemDate);
                }
                var query = (
                    squel.insert()
                        .into("Albums")
                        .set("AlbumName", AlbumName)
                        .set("ArtistName", ArtistName)
                        .set("FilterCategoryID", FilterCategoryID)
                        .set("Description", Description)
                        .set("PicturePath", PicturePath)
                        .set("ReleaseDate", releaseDay.toJSON())
                        .set("Price", Price)
                        .set("StokAmount", StokAmount)
                        .set("addToSystemDate", addToDay.toJSON())
                        .toString()
                );
                DButilsAzure.Insert(query)
                    .then(function (result) {
                        //console.log(result);
                        res.send(result);
                    })
                    .catch(function (err) {
                        res.sendStatus(400)
                    });
            }
            else {
                res.send("you are not Admin, you cant remove clients");
                console.log('you are not Admin, you cant add albums');
            }
        })

});
//-----------------------------------------------------------------------
root.delete('/removeAlbum', function (req,res) {
	var idAlbumToDelete = req.body.AlbumsID;
    console.log(idAlbumToDelete);
	if(!req.body.AlbumsID || !req.body.usernameAdmin){
		res.send("please enter id to delete and admin username");
		return;
	}
    var query = "Select * from Clients where Username='"+req.body.usernameAdmin+"' and isADmin='1'" ;
    DButilsAzure.Select(query)
        .then(function (result) {
            if(result.length>0) {
                var query = "DELETE FROM Albums WHERE AlbumID='" + idAlbumToDelete + "'";
                console.log(query);
                DButilsAzure.Delete(query)
                    .then(function (result) {
                        res.send(result);
                    })
                    .catch(function (err) {
                        res.sendStatus(400)
                    });
            }
            else {
                    res.send("you are not Admin, you cant remove albums");
                    console.log('you are not Admin, you cant remove albums');

            }
        })

});
//-------------------------------------------------------------------------------------------------------------------
root.get('/topFive', function (req,res) {
	var lastweek = moment().subtract(7,'days');
    var query = "Select * from Albums Join (Select top 5 AlbumsInOrders.AlbumID, count(*) as cnt From AlbumsInOrders JOIN Orders on Orders.OrderID=AlbumsInOrders.OrderID where (Orders.OrderDate >'"+lastweek.toJSON()+"') GROUP BY AlbumsInOrders.AlbumID ORDER BY cnt DESC) as topFive on Albums.AlbumID=topFive.AlbumID";
    DButilsAzure.Select(query)
		.then(function(result) {
			console.log ('GET news albums success');
        	res.send(result);
    })
		.catch(function (err){
			console.log(err.message);
			res.send(400)
		});

});
//-------------------------------------------------------------------------------------------------------------------
root.get('/getNewAlbums', function (req,res) {
    var lastmonth = moment().subtract(30,'days');
    var query = "Select * from Albums  where Albums.addToSystemDate>'"+lastmonth.toJSON()+"'" ;
    DButilsAzure.Select(query)
        .then(function(result) {
            console.log ('GET news albums success');
            res.send(result);
        })
        .catch(function (err){
            console.log(err.message);
            res.send(400)
        });

});
//-------------------------------------------------------------------
root.get('/SearchByArtistName/:id', function (req,res) {
    if(!req.params.id)
        res.send("please put name of artist");
    else {
        var ArtistName = req.params.id;
        var query = (
            squel.select()
                .from("Albums")
                .where("ArtistName = ?", ArtistName)
                .toString()
        );
        DButilsAzure.Select(query)
            .then(function (result) {
                if (result.length > 0) {
                    res.send(result);
                }
                else {
                    console.log('didnt found');
                    res.send(400);
                }
            })

            .catch(function (err) {
                console.log(err.message);
                res.send(400);
            });
    }
    });
//-------------------------------------------------------------------
root.get('/searchByAlbumName/:id', function (req,res) {
    var AlbumName = req.params.id;
    if (!req.params.id) {
        res.send("please put name of artist");
    }
    else {
        var AlbumName = req.params.id;
        var query = (
            squel.select()
                .from("Albums")
                .where("AlbumName = ?", AlbumName)
                .toString()
        );
        DButilsAzure.Select(query)
            .then(function (result) {
                if (result.length > 0) {
                    res.send(result);
                }
                else {
                    console.log('didnt found');
                    res.send(400);
                }
            })

            .catch(function (err) {
                console.log(err.message);
                res.send(400);
            });
    }
});
//------------------------------------------------------------------------------------------
root.get('/getFilterCategories', function (req,res) {
    DButilsAzure.Select('Select * from FilterCategories').then(function (result) {
        res.send(result);
    })
        .catch(function (err) {
            console.log(err.message);
            res.send(400);
        });
});
//-------------------------------------------------------------------
root.get('/filterByCategory/:id', function (req,res) {
    if(!req.params.id){
        res.send("please put id of category");
    }
    else {
        var categoryID = req.params.id;
        var query = (
            squel.select()
                .from("Albums")
                .where("FilterCategoryID = ?", categoryID)
                .toString()
        );
        DButilsAzure.Select(query)
            .then(function (result) {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                console.log('didnt found');
                res.send("dont exist");
            }
        });
    }
});
// //------------------------------------------------------------------
root.get('/getSortCategories', function (req,res) {
    DButilsAzure.Select('Select * from SortCategories')
        .then(function(result) {
        res.send(result);

    })
            .catch(function (err) {
                console.log(err.message);
                res.send(400);
            });
});
// //----------------------------------------------------------------
root.get('/sortByCategory/:id', function(req,res){
    if(!req.params.id)
    {
        res.send("please put id of category");
    }
    else {
        var categoryID = req.params.id;
        var categoryName = "nathing";
        if (categoryID == 1) {
            categoryName = "Price"
        }
        if (categoryID == 2) {
            categoryName = "AlbumName"
        }
        if (categoryID == 3) {
            categoryName = "ArtistName"
        }
        if (!(categoryName === "nathing")) {
            var query = (
                squel.select()
                    .from("Albums")
                    .order(categoryName, true)
                    .toString()
            );
            DButilsAzure.Select(query)
                .then(function (result) {
                if (result.length > 0) {
                    res.send(result);
                }
                else {
                    console.log('didnt found');
                    res.send("or nathing to see");
                }
            })
                .catch(function (err) {
                    console.log(err.message);
                    res.send(400);
                });
        }
        else {
            console.log('didnt found');
            res.send("no such category");
        }
    }
});
//--------------------------------------------------------
root.get('/getInventory', function(req,res){
   var query = "select AlbumID,AlbumName,StokAmount from Albums";
    DButilsAzure.Select(query)
        .then(function (result) {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                console.log('didnt found');
                res.send("or nathing to see");
            }
        })
        .catch(function (err) {
            console.log(err.message);
            res.send(400);
        });
});
//--------------------------------------------------------------
root.post('/updateInventory', function (req,res) {
    if (!req.body.AlbumID || !req.body.StokAmount || !req.body.usernameAdmin) {
        res.send("please enter Album ID and Quentity and admin username");
    }
    else {
        var query = "Select * from Clients where Username='" + req.body.usernameAdmin + "' and isADmin='1'";
        DButilsAzure.Select(query)
            .then(function (result) {
                if (result.length > 0) {
                    var query = "UPDATE Albums SET StokAmount='" + req.body.StokAmount + "' where AlbumID='" + req.body.AlbumID + "' ";
                    DButilsAzure.Update(query)
                        .then(function (result) {
                            res.send(result);
                        })
                        .catch(function (err) {
                            console.log("something went wrong");
                            res.sendStatus(400);
                        });
                }
                else {
                    res.send("you are not Admin, you cant remove clients");
                    console.log('you are not Admin, you cant remove clients');
                }
            })
    }
});


//-------------------------------------------------------------------------------------------------------------------
root.get('/getClients', function (req,res) {
	DButilsAzure.Select('Select * from Clients')
        .then(function(result) {
		res.send(result);

	})
        .catch(function (err) {
            console.log(err.message);
            res.send(400);
        });
});
//-------------------------------------------------------------------------------------------------------------------
root.get('/getSpecificClient/:id', function (req,res) {
    if(!req.params.id){
        res.send("please put Username");
    }else {
        var Username = req.params.id;
        var query = (
            squel.select()
                .from("Clients")
                .where("Username = ?", Username)
                .toString()
        );
        DButilsAzure.Select(query)
            .then(function (result) {
            if (result.length > 0) {
                res.send(result);
            }
            else {
                console.log('GET client faild, Incorrect Username');
                res.send("GET client faild, Incorrect Username");
            }
        })
            .catch(function (err) {
                console.log(err.message);
                res.send(400);
            });
    }
});
//---------------------------------------------------------
root.get('/getOrdersHistory',function (req,res) {
    var query = "select * from Orders";
    DButilsAzure.Select(query)
        .then(function (result) {
            res.send(result);
        })
        .catch(function (err) {
            console.log(err.message);
            res.send(400);
        });
});
//---------------------------------------------------------
root.get('/getOrdersHistory',function (req,res) {
    var query = "select * from Orders";
    DButilsAzure.Select(query)
        .then(function (result) {
            res.send(result);
        })
        .catch(function (err) {
            console.log(err.message);
            res.send(400);
        });
});
//-------------------------------------------------
root.get('/getHistoryOrdersByID/:id',function (req,res) {
    if(!req.params.id){
        console.log("please enter username");
    }
    else {
        var userName = req.params.id;
        var query = "select * from Orders where Username='"+userName+"'";
        DButilsAzure.Select(query)
            .then(function (result) {
                if(result.length>0)
                    res.send(result);
                else
                    res.send("no order for this username");
            })
            .catch(function (err) {
                console.log(err.message);
                res.send(400);
            });
    }
});
//----------------------------------------------------------------------------------------------------------------------
root.get('/getRecommendedPerClient/:id',function (req,res) {
    if(!req.params.id){
        console.log("please enter username");
    }
    else{
        var userName = req.params.id;
        var queryBestCat1 = "Select favoriteCategory1 from Clients where Username='"+userName+"'";
        var queryBestCat2 = "Select favoriteCategory2 from Clients where Username='"+userName+"'";
        var query = "Select top 5 * from Albums where FilterCategoryID = (" +queryBestCat1+ ") OR FilterCategoryID = (" +queryBestCat2+")";
        DButilsAzure.Select(query)
            .then(function(result){
                    res.send(result);
                })
            .catch(function (err) {
                console.log(err.message);
                res.sendStatus(400);
            });
    }
});
//----------------------------------------------------------------------------------------------------------------------
root.post('/startNewPurchase',function (req,res) {
   if(!req.body.Username)
   {
       res.send("please enter username");
   }
   var username = req.body.Username;
   var date = moment();
   var query = "Insert into Orders (Username,OrderDate) Values ('"+username+"', '"+date.toJSON()+"')";
   DButilsAzure.Insert(query)
       .then(function(result){
           res.send(result);
       })
           .catch(function (err) {
               console.log(err.message);
               res.sendStatus(400);
           });
});
//----------------------------------------------------------------------
root.post('/getOrderID',function(req,res){
    if(!req.body.Username || !req.body.OrderDate)
    {
        res.send("please enter username and order date");
    }
    else {
        var now = req.body.OrderDate;
        var dayBefore = moment(now).subtract(1,'days');
        var dayAfter = moment(now).add(1,'days');
        var query = "Select OrderID from Orders where Username='" + req.body.Username + "' and OrderDate >'"+dayBefore.toJSON() + "' and OrderDate <'"+dayAfter.toJSON()+"'";
        DButilsAzure.Select(query)
            .then(function (result) {
                res.send(result);
            })
            .catch(function (err) {
                console.log(err.message);
                res.sendStatus(400);
            });
    }
});
//---------------------------------------------------------------------------
root.get('/getOrderDetail/:id',function (req,res) {
    if(!req.params.id){
        res.send("please enter OrderID");
        return;
    }
    else{
        var query = "Select AlbumID,Amount from AlbumsInOrders where OrderID='"+req.params.id+"'";
        DButilsAzure.Select(query)
            .then(function (result) {
                res.send(result);
            })
            .catch(function (err) {
                console.log(err.message);
                res.sendStatus(400);
            });
    }
});
//------------------------------------------------------------------------------------
root.get('/getTotalPrice/:id',function (req,res) {
    if(!req.params.id){
        res.send("please enter OrderID");
        return;
    }
    else {
        var orderId = req.params.id;
        var query= "Select SUM(oi.Amount * al.price) AS grand_total From AlbumsInOrders AS oi JOIN Albums AS al ON oi.AlbumID=al.AlbumId where oi.OrderID='"+orderId+"'";
        DButilsAzure.Select(query)
            .then(function (result) {
                res.send(result);
            })
            .catch(function (err) {
                console.log(err.message);
                res.sendStatus(400);
            });
    }
});
//--------------------------------------------------------------------------------
root.post('/addItemToPurchase',function (req,res) {
    if(!req.body.OrderID || !req.body.AlbumID || !req.body.Amount){
        res.send("please enter orderID and AlbumID and Amount");
        return;
    }
    else{
        var orderId = req.body.OrderID;
        var albumId = req.body.AlbumID;
        var amount = req.body.Amount;
        var query = "Select StokAmount as MaxAmount from Albums where AlbumID='"+albumId+"'";
        DButilsAzure.Select(query)
            .then(function (result) {
                if(result.length == 1)
                {
                    console.log("got Amount");
                    if(amount>result[0].MaxAmount) {
                        amount = result[0].MaxAmount;
                        console.log("Amount is bigger then StokAmount");
                    }
                    var maxAmount = result[0].MaxAmount;
                    query = "Insert into AlbumsInOrders (OrderID,AlbumID,Amount) Values ('" + orderId + "','" +albumId+"','"+amount+"')";
                    DButilsAzure.Insert(query)
                        .then(function (result) {
                            maxAmount = maxAmount - amount;
                            query = "UPDATE Albums SET StokAmount='"+maxAmount+"' where AlbumID='"+albumId+"' ";
                            DButilsAzure.Update(query)
                                .then(function (result) {
                                    res.send("add item succeed");
                                })
                        })
                }
                else{
                    res.send("no such albumID");
                }
            })
            .catch(function (err) {
                console.log(err.message);
                res.sendStatus(400);
            })
    }
});
//----------------------------------------------------------------------------------------------------------------------
root.post('/DeleteItemToPurchase',function (req,res) {
    if(!req.body.OrderID || !req.body.AlbumID || !req.body.Amount){
        res.send("please enter orderID and AlbumID and amount");
        return;
    }
    else{
        var orderId = req.body.OrderID;
        var albumId = req.body.AlbumID;
        var amount = req.body.Amount;
        var AmountFromOrder;
        var query = "Select StokAmount as MaxAmount from Albums where AlbumID='"+albumId+"'";
        DButilsAzure.Select(query)
            .then(function (result) {
                if (result.length == 1) {
                    var maxAmount = result[0].MaxAmount;
                    query = "Select Amount as AmountFromOrder from AlbumsInOrders where OrderID='"+orderId+"' and AlbumID='" + albumId + "'";
                    DButilsAzure.Select(query)
                        .then(function (result) {
                            if (result.length > 0) {
                                AmountFromOrder = result[0].AmountFromOrder;
                                console.log("Amount="+AmountFromOrder);
                            }
                            var query = "Delete from AlbumsInOrders Where OrderID='" + orderId + "' and AlbumID='" + albumId + "'";
                            DButilsAzure.Delete(query)
                                .then(function (result) {
                                    console.log("deleted from AlbumsInOrders table");
                                    maxAmount = +maxAmount + +AmountFromOrder;
                                    query = "UPDATE Albums SET StokAmount='" + maxAmount.toString() + "' where AlbumID='" + albumId + "' ";
                                    DButilsAzure.Update(query)
                                        .then(function (result) {
                                            res.send("update invetory succeed");
                                        })
                                })
                        })
                }
                else {
                    res.send("no such albumID");
                }
            })
    }
});
//----------------------------------------------------------------------------------------------------------------------
root.post('/makePurchase',function (req,res) {
    if(!req.body.OrderID || !req.body.TotalPrice || !req.body.DateDeilvery){
        res.send("please enter OrderID and DateDeilvery and TotalPrice");
        return;
    }
    else{
        var orderId = req.body.OrderID;
        var totalPrice = req.body.TotalPrice;
        var deliveryDate =moment(req.body.DateDeilvery);
        var query = "UPDATE Orders SET DeliveryDate='"+deliveryDate.toJSON()+"', TotalAmount='"+totalPrice+"' where OrderID ='"+orderId+"' ";
        DButilsAzure.Update(query)
            .then(function (result) {
                res.send("update DeliveryDate succeed update TotalPrice succeed, Purchase Succeed!");
            })
    }
});
//-------------------------------------------------------------------------------------------------------------------
root.get('/AvailableUsername/:id', function (req,res) {
    var usernameWish = req.params.id;
    var query =(
        squel.select()
            .from("Clients")
            .where("Username = ?", usernameWish)
            .toString()
    );
    DButilsAzure.Select(query)
        .then(function(result) {
        if (result.length > 0) {
            res.send("username is not available, already used!");
            console.log ('username exist');
        }
        else {
            console.log ('username free');
            res.send("username is free!");
        }
	});
});
//------------------------------------------------------------------
root.get('/isUserAdmin/:id',function (req,res) {
    var  username = req.params.id;
    var query ="Select * from Clients where Username='"+username+"' and isADmin='1'";
    DButilsAzure.Select(query)
        .then(function (result) {
            if(result.length>0){
                res.send("true");
                console.log('userIsAdmin');
            }
            else {
                res.send("false");
                console.log('user is not admin');
            }
        })
        .catch(function (err) {
            console.log(err.message);
            res.sendStatus(400);
        })
});


//------------------------------------------------------------------
root.post('/registerClient', function(req, res){
    var Username= req.body.Username;
    var Password = req.body.Password;
    var FirstName = req.body.FirstName;
    var LastName = req.body.LastName;
    var Adress = req.body.Adress;
    var City = req.body.City;
    var Phone = req.body.Phone;
    var Cellular = req.body.Cellular;
    var CreditCardNumber = req.body.CreditCardNumber;
    var favoriteCategory1 = req.body.favoriteCategory1;
    var favoriteCategory2 = req.body.favoriteCategory2;
    var country = req.body.Country;
    var isADmin = req.body.isADmin;
    var Mail = req.body.Mail;
    if(!Username || !Password){
        console.log('faild to login');
        res.send({"result": false});
    }
    else {
        var query =(
            squel.insert()
                .into("Clients")
                .set("Username", Username)
                .set("Password", Password)
                .set("FirstName", FirstName)
                .set("LastName", LastName)
                .set("Adress", Adress)
                .set("City", City)
                .set("Phone", Phone)
                .set("Cellular", Cellular)
                .set("CreditCardNumber", CreditCardNumber)
                .set("favoriteCategory1",favoriteCategory1)
                .set("favoriteCategory2",favoriteCategory2)
                .set("Country",country)
                .set("isADmin",isADmin)
                .set("Mail",Mail)
                .toString()
        );
        DButilsAzure.Insert(query)
            .then(function(result) {
            console.log(result);
            res.send(result);
        }).catch(function (err) {
            console.log(err.message);
            res.sendStatus(400);
        })
    }
});
//-------------------------------------------------------------------------------------------
root.post('/Login', function(req, res){
	var Username= req.body.Username;
	var Password = req.body.Password;
	if(!Username || !Password){
		console.log('faild to login');
		res.send({"result": false});
	}
	else {
		var query =(
		    squel.select()
		        .from("Clients")
		        .where("Username = ?", Username)
		        .where("Password = ?", Password)
		        .toString()
			);
			DButilsAzure.Select(query)
                .then(function(result) {
				if (result.length > 0) {
				    query = "UPDATE Clients SET lastTimeLoginIn='" + moment().toJSON() + "' where Username='" + Username + "' ";
				    DButilsAzure.Update(query)
                        .then(function (result) {
                            res.send({"result": true});
                            console.log ('login success');
                        })
                        .catch(function (err) {
                            console.log(err.message);
                            res.sendStatus(400);
                        })
				}
				else {
					res.send({"result": false});
					console.log('faild to login');
				}
			});
		}
});
//------------------------------------------------------------------------------------------------
root.post('/removeClient', function (req,res) {
   if(!req.body.Username || !req.body.usernameAdmin){
       res.send("please enter username to delete, and your username to see if you're admin");
       return;
   }
   else {
       var usernameToDelete = req.body.Username;
       var usernameAdmin = req.body.usernameAdmin;
       var query = "Select * from Clients where Username='"+usernameAdmin+"' and isADmin='1'" ;
       DButilsAzure.Select(query)
           .then(function (result) {
               if(result.length>0){
                   query = "DELETE FROM Clients WHERE Username='"+usernameToDelete+"'";
                   DButilsAzure.Delete(query)
                       res.send(result);
                       console.log("remove client succeed!");
               }
               else{
                   res.send("you are not Admin, you cant remove clients");
                   console.log('you are not Admin, you cant remove clients');
               }
           })
           .catch(function (err) {
               console.log(err.message);
               res.sendStatus(400);
           })
   }
});
//-----------------------------------------------------------------------------------------------
root.post('/validitionQuestionForPassword', function (req,res) {
    if (!req.body.Username || !req.body.City || !req.body.LastName) {
        res.send("please enter username to delete, and your username to see if you're admin");
        return;
    }
    else {
        var username = req.body.Username;
        var City = req.body.City;
        var LastName = req.body.LastName;
        var query = "Select * from Clients where Username='"+username+"' and City='"+City+"' and LastName='"+LastName+"' ";
        DButilsAzure.Select(query)
            .then(function (result) {
                if(result.length>0){
                    query = "Select Password from Clients where Username='"+username+"'";
                    DButilsAzure.Select(query)
                        .then(function (result) {
                            res.send(result);
                            console.log("here is your password:"+result);
                        })
                        .catch(function (err) {
                            console.log(err.message);
                            res.sendStatus(400);
                        })
                }
                else{
                    res.send("false, you are not the guy!");
                    console.log("wrong valid");
                }
            })
            .catch(function (err) {
                console.log(err.message);
                res.sendStatus(400);
            })
    }
});